
document.addEventListener('DOMContentLoaded', () => {
    const learnButton = document.getElementById('learn-btn');
    const statusEl = document.getElementById('status');
    
    // Conectar a SocketIO del servidor
    const socket = io("https://Nexus-Alpha-Team.guilledeleon.repl.co");
    
    // Listener para recibir el resultado del OCR desde el servidor
    socket.on('ocr_result', (ocrResult) => {
        console.log("📥 Resultado de OCR recibido:", ocrResult);
        
        if (ocrResult.success) {
            statusEl.textContent = `OCR encontró: ${ocrResult.asset_guess} (${ocrResult.price_guess})... Buscando en WebSockets...`;
            
            // Ahora, le pasa la verdad fundamental al background script para continuar
            chrome.runtime.sendMessage({ 
                action: "find_message_match", 
                ground_truth: ocrResult 
            });
        } else {
            statusEl.textContent = `Error en OCR: ${ocrResult.error}`;
            learnButton.disabled = false;
        }
    });

    // Listener para conexión exitosa
    socket.on('connect', () => {
        console.log("🔗 Conectado al servidor vía SocketIO");
    });

    // Listener para errores de conexión
    socket.on('connect_error', (error) => {
        console.error("❌ Error de conexión SocketIO:", error);
        statusEl.textContent = "Error: No se pudo conectar al servidor.";
        learnButton.disabled = false;
    });

    learnButton.addEventListener('click', () => {
        learnButton.disabled = true;
        statusEl.textContent = "Iniciando aprendizaje...";

        // Paso 1: Enviar mensaje al background para que empiece a escuchar WebSockets
        chrome.runtime.sendMessage({ action: "start_listening" });
        statusEl.textContent = "Escuchando red del bróker...";

        // Paso 2: Tomar una captura de pantalla de la pestaña actual
        chrome.tabs.captureVisibleTab(null, { format: "png" }, (dataUrl) => {
            if (!dataUrl) {
                statusEl.textContent = "Error: No se pudo capturar la pestaña.";
                learnButton.disabled = false;
                return;
            }
            
            statusEl.textContent = "Enviando imagen al Cerebro...";
            console.log("📷 Captura de pantalla obtenida, enviando vía SocketIO...");
            
            // Envía la imagen a través de nuestro canal seguro SocketIO
            socket.emit('request_ocr', { image_data: dataUrl });
        });
    });

    // Listener para mensajes del background script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === "websocket_captured") {
            statusEl.textContent = "WebSocket capturado! Generando parser...";
            console.log("🕸️ WebSocket capturado:", message.data);
            
            // Aquí se podría enviar al servidor para generar el parser
            // Por ahora, mostrar éxito
            setTimeout(() => {
                statusEl.textContent = "¡Bróker aprendido exitosamente!";
                learnButton.disabled = false;
            }, 2000);
        }
        
        if (message.action === "parser_generated") {
            statusEl.textContent = "¡Parser generado! Bróker completamente aprendido.";
            learnButton.disabled = false;
            console.log("🎯 Parser generado:", message.parser);
        }
        
        if (message.action === "learning_failed") {
            statusEl.textContent = "Error: No se pudo aprender el bróker.";
            learnButton.disabled = false;
            console.error("❌ Aprendizaje fallido:", message.error);
        }
    });
});

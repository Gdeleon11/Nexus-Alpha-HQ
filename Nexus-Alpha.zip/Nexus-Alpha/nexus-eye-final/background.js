
let targetTabId = null;
let isListening = false;
let groundTruth = null;
let capturedMessages = [];
let messageCaptureDuration = 10000; // 10 seconds to capture messages

// Escucha los mensajes del popup (nuestra UI)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "start_listening") {
        isListening = true;
        capturedMessages = []; // Limpiar mensajes anteriores
        
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                targetTabId = tabs[0].id;
                attachDebugger(targetTabId);
                
                // Comenzar a capturar mensajes por un tiempo determinado
                setTimeout(() => {
                    console.log(`Captured ${capturedMessages.length} messages for analysis`);
                }, messageCaptureDuration);
            }
        });
    } else if (request.action === "find_message_match") {
        groundTruth = request.ground_truth;
        findMessageMatch();
    }
});

function attachDebugger(tabId) {
    chrome.debugger.attach({ tabId }, "1.3", () => {
        if (chrome.runtime.lastError) {
            console.error("Error al adjuntar: ", chrome.runtime.lastError.message);
            notifyPopup("learning_failed", "No se pudo adjuntar al bróker");
            return;
        }
        console.log("Nexus-Eye: Agente infiltrado. Adjunto a la pestaña:", tabId);
        chrome.debugger.sendCommand({ tabId }, "Network.enable");
        notifyPopup("learning_progress", "Escuchando comunicaciones WebSocket...");
    });
}

function detachDebugger() {
    if (targetTabId) {
        chrome.debugger.detach({ tabId: targetTabId });
        console.log("Nexus-Eye: Agente retirado. Debugger separado.");
        targetTabId = null;
    }
}

// El corazón del espía: escucha los eventos de red
chrome.debugger.onEvent.addListener((source, method, params) => {
    if (method === "Network.webSocketFrameReceived" && source.tabId === targetTabId && isListening) {
        const payload = params.response.payloadData;
        
        // Filtrar mensajes obvios de heartbeat/ping
        if (!payload.includes("_placeholder") && 
            !payload.includes("ping") && 
            !payload.includes("pong") &&
            payload.length > 10) {
            
            capturedMessages.push({
                timestamp: Date.now(),
                payload: payload,
                length: payload.length
            });
            
            // Limitar a los últimos 50 mensajes para evitar memoria excesiva
            if (capturedMessages.length > 50) {
                capturedMessages = capturedMessages.slice(-50);
            }
        }
    }
});

function findMessageMatch() {
    if (!groundTruth || capturedMessages.length === 0) {
        notifyPopup("learning_failed", "No hay datos suficientes para el aprendizaje");
        return;
    }
    
    notifyPopup("learning_progress", `Analizando ${capturedMessages.length} mensajes WebSocket...`);
    
    let bestMatch = null;
    let bestScore = 0;
    
    for (const msgData of capturedMessages) {
        try {
            const msg = msgData.payload;
            
            // Intentar extraer JSON del mensaje
            let jsonData = null;
            
            // Buscar patrones comunes de JSON en mensajes WebSocket
            if (msg.includes('[') && msg.includes(']')) {
                const jsonStart = msg.indexOf('[');
                const jsonStr = msg.substring(jsonStart);
                try {
                    jsonData = JSON.parse(jsonStr);
                } catch (e) {
                    // Ignorar errores de parsing
                }
            } else if (msg.includes('{') && msg.includes('}')) {
                const jsonStart = msg.indexOf('{');
                const jsonStr = msg.substring(jsonStart);
                try {
                    jsonData = JSON.parse(jsonStr);
                } catch (e) {
                    // Ignorar errores de parsing
                }
            }
            
            if (jsonData) {
                const score = calculateMatchScore(jsonData, groundTruth);
                if (score > bestScore) {
                    bestScore = score;
                    bestMatch = {
                        message: msg,
                        jsonData: jsonData,
                        score: score
                    };
                }
            }
            
        } catch (error) {
            console.log("Error procesando mensaje:", error);
        }
    }
    
    if (bestMatch && bestScore > 0.3) { // Umbral de confianza
        generateParser(bestMatch, groundTruth);
    } else {
        notifyPopup("learning_failed", "No se encontró coincidencia en los mensajes WebSocket");
    }
}

function calculateMatchScore(jsonData, groundTruth) {
    let score = 0;
    const dataStr = JSON.stringify(jsonData).toLowerCase();
    
    // Buscar el asset en el mensaje
    if (groundTruth.asset_guess) {
        const asset = groundTruth.asset_guess.toLowerCase();
        const assetParts = asset.split(/[-\/]/);
        
        for (const part of assetParts) {
            if (part.length >= 3 && dataStr.includes(part)) {
                score += 0.4;
            }
        }
    }
    
    // Buscar el precio en el mensaje
    if (groundTruth.price_guess) {
        const priceStr = groundTruth.price_guess.toString();
        
        // Buscar números similares al precio
        const numbers = dataStr.match(/\d+\.?\d*/g) || [];
        for (const num of numbers) {
            const numValue = parseFloat(num);
            const priceValue = parseFloat(priceStr);
            
            if (Math.abs(numValue - priceValue) < priceValue * 0.1) { // 10% tolerance
                score += 0.5;
            }
        }
    }
    
    return Math.min(score, 1.0); // Cap at 1.0
}

function generateParser(bestMatch, groundTruth) {
    notifyPopup("learning_progress", "Generando intérprete personalizado...");
    
    // Llamar al endpoint para generar el parser
    fetch("https://nexus-alpha-system.replit.dev/api/generate_parser", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            websocket_message: bestMatch.message,
            ground_truth: groundTruth,
            match_score: bestMatch.score
        })
    })
    .then(res => res.json())
    .then(result => {
        if (result.success) {
            // Guardar el parser en el almacenamiento local
            const brokerDomain = getBrokerDomain();
            chrome.storage.local.set({ 
                [`parser_${brokerDomain}`]: result.parser,
                [`parser_metadata_${brokerDomain}`]: {
                    created: Date.now(),
                    ground_truth: groundTruth,
                    match_score: bestMatch.score
                }
            }, () => {
                notifyPopup("learning_complete", brokerDomain);
                detachDebugger();
                isListening = false;
            });
        } else {
            notifyPopup("learning_failed", result.error || "Error generando parser");
        }
    })
    .catch(error => {
        notifyPopup("learning_failed", `Error de conexión: ${error.message}`);
    });
}

function getBrokerDomain() {
    // Obtener el dominio del bróker actual
    return new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0] && tabs[0].url) {
                const url = new URL(tabs[0].url);
                resolve(url.hostname);
            } else {
                resolve('unknown_broker');
            }
        });
    });
}

function notifyPopup(action, data) {
    chrome.runtime.sendMessage({ 
        action: action, 
        broker: typeof data === 'string' ? data : undefined,
        reason: typeof data === 'string' ? data : undefined,
        message: typeof data === 'string' ? data : undefined
    });
}

// Limpia si la pestaña se cierra
chrome.tabs.onRemoved.addListener((tabId) => {
    if (tabId === targetTabId) {
        detachDebugger();
        isListening = false;
    }
});

// Limpia si el debugger se desconecta
chrome.debugger.onDetach.addListener((source, reason) => {
    if (source.tabId === targetTabId) {
        console.log("Nexus-Eye: Debugger separado:", reason);
        targetTabId = null;
        isListening = false;
    }
});

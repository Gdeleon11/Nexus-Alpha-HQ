
"""
Dynamic Tools Package
Contiene herramientas generadas dinámicamente por Deepseek Engineer
"""

import os
import importlib.util
from typing import Dict, Any, List

def load_dynamic_tool(tool_id: str):
    """
    Cargar una herramienta dinámica por su ID.
    
    Args:
        tool_id: ID de la herramienta a cargar
        
    Returns:
        Módulo de la herramienta cargada
    """
    tool_file = os.path.join(os.path.dirname(__file__), f"{tool_id}.py")
    
    if not os.path.exists(tool_file):
        raise FileNotFoundError(f"Herramienta {tool_id} no encontrada")
    
    spec = importlib.util.spec_from_file_location(tool_id, tool_file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    
    return module

def get_available_tools() -> List[str]:
    """
    Obtener lista de herramientas disponibles.
    
    Returns:
        Lista de IDs de herramientas disponibles
    """
    tools_dir = os.path.dirname(__file__)
    tools = []
    
    for filename in os.listdir(tools_dir):
        if filename.endswith('.py') and filename != '__init__.py':
            tools.append(filename[:-3])  # Remover .py
    
    return tools

def execute_dynamic_tool(tool_id: str, data, **kwargs):
    """
    Ejecutar una herramienta dinámica.
    
    Args:
        tool_id: ID de la herramienta
        data: Datos para procesar
        **kwargs: Argumentos adicionales
        
    Returns:
        Resultado de la herramienta
    """
    try:
        module = load_dynamic_tool(tool_id)
        
        # Buscar la función principal de análisis
        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if callable(attr) and not attr_name.startswith('_'):
                return attr(data, **kwargs)
        
        raise ValueError(f"No se encontró función ejecutable en {tool_id}")
        
    except Exception as e:
        raise RuntimeError(f"Error ejecutando herramienta {tool_id}: {str(e)}")

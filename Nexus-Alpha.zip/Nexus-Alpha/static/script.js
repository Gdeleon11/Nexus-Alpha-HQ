document.addEventListener('DOMContentLoaded', function () {
    let socket;
    let reconnectionAttempts = 0;
    const maxReconnectionAttempts = 10;

    function initializeSocket() {
        socket = io({
            reconnection: true,
            reconnectionDelay: 1000,
            reconnectionDelayMax: 5000,
            maxReconnectionAttempts: maxReconnectionAttempts,
            timeout: 20000,
            forceNew: false,
            transports: ['polling', 'websocket']
        });

        const logPanel = document.getElementById('log-activity-content');
        const signalPanel = document.getElementById('signal-panel-content');
        const chatMessages = document.getElementById('chat-messages');
        const commandInput = document.getElementById('command-input');
        const sendCommandBtn = document.getElementById('send-command-btn');

        function addMessage(panel, content, isHtml = false) {
            if (!panel) return;
            const entry = document.createElement('div');
            entry.className = 'log-entry';
            if (isHtml) {
                entry.innerHTML = content;
            } else {
                entry.textContent = content;
            }
            panel.appendChild(entry);
            panel.scrollTop = panel.scrollHeight;
        }

        function addChatMessage(message, sender) {
            if (!chatMessages) return;
            const entry = document.createElement('div');
            entry.className = `chat-entry ${sender}`;
            entry.innerHTML = `<p><strong>${sender === 'user' ? 'CEO' : 'Director'}:</strong> ${message}</p>`;
            chatMessages.appendChild(entry);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        // Eventos de Socket.IO
        socket.on('connect', () => {
            console.log('Socket.IO Conectado!');
            reconnectionAttempts = 0;
            addMessage(logPanel, '<strong>✅ Conectado al Cerebro de Nexus-Alpha.</strong>', true);
        });

        socket.on('disconnect', () => {
            console.log('Socket.IO Desconectado!');
            addMessage(logPanel, '<strong>⚠️ Desconectado del Cerebro de Nexus-Alpha.</strong>', true);
        });

        socket.on('connect_error', (error) => {
            console.error('Error de conexión de Socket.IO:', error);
            reconnectionAttempts++;
            if (reconnectionAttempts <= maxReconnectionAttempts) {
                addMessage(logPanel, `<strong>❌ Error de conexión (${reconnectionAttempts}/${maxReconnectionAttempts}). Reintentando...</strong>`, true);
            } else {
                addMessage(logPanel, '<strong>💀 Demasiados errores de conexión. Recargue la página.</strong>', true);
            }
        });

        socket.on('reconnect', (attemptNumber) => {
            console.log('Socket.IO Reconectado después de', attemptNumber, 'intentos');
            reconnectionAttempts = 0;
            addMessage(logPanel, '<strong>🔄 Reconectado exitosamente.</strong>', true);
        });

        socket.on('new_log', function(msg) {
            console.log('Log recibido:', msg.data);
            addMessage(logPanel, msg.data);
        });

        socket.on('new_signal', function(signal) {
            console.log('Señal recibida:', signal);
            displaySignalCard(signal);
        });

        function displaySignalCard(signal) {
            if (!signalPanel) return;

            const cardId = `signal-${signal.signal_id}`;
            const existingCard = document.getElementById(cardId);
            if (existingCard) {
                existingCard.remove();
            }

            const card = document.createElement('div');
            card.id = cardId;
            card.className = 'signal-card';
            card.innerHTML = `
        <div class="signal-header">
            <h3>${signal.pair} <span class="asset-type">${signal.type}</span></h3>
            <span class="verdict-badge verdict-${signal.verdict.toLowerCase().replace(' ', '-')}">${signal.verdict}</span>
        </div>
        <div class="signal-details">
            <p><strong>Timeframe:</strong> ${signal.timeframe}</p>
            <p><strong>Trigger:</strong> ${signal.trigger}</p>
            <p><strong>Timestamp:</strong> ${signal.timestamp}</p>
        </div>
        <div class="analysis-results">
            <div class="analysis-item">
                <strong>🧠 Cognitivo:</strong> ${signal.cognitive}
            </div>
            <div class="analysis-item">
                <strong>🔮 Predictivo:</strong> ${signal.predictive.prediction} (${(signal.predictive.confidence * 100).toFixed(0)}%)
            </div>
            <div class="analysis-item">
                <strong>🌍 Macro:</strong> ${signal.macro}
            </div>
            <div class="analysis-item">
                <strong>📱 Social:</strong> ${signal.social}
            </div>
            <div class="analysis-item">
                <strong>🔗 Correlación:</strong> ${signal.correlation}
            </div>
            <div class="analysis-item">
                <strong>🔬 Causal:</strong> ${signal.causal}
            </div>
            <div class="analysis-item">
                <strong>🎯 RLHF:</strong> ${signal.rlhf}
            </div>
            <div class="analysis-item">
                <strong>🎥 Multimodal:</strong> ${signal.multimodal}
            </div>
        </div>
        <div class="signal-actions">
            <button class="btn btn-success" onclick="markSignalResult('${signal.signal_id}', 'WIN')">✅ Ganada</button>
            <button class="btn btn-danger" onclick="markSignalResult('${signal.signal_id}', 'LOSS')">❌ Perdida</button>
            <button class="btn btn-info" onclick="showExplanation('${signal.signal_id}')">🔍 Ver Análisis de Decisión</button>
            <select id="override-reason-${signal.signal_id}" class="override-select" style="display: none;">
                <option value="">Ignoré esta señal por:</option>
                <option value="Mal Timing">Mal Timing</option>
                <option value="Alto Spread">Alto Spread</option>
                <option value="Volatilidad Inesperada">Volatilidad Inesperada</option>
                <option value="Instinto del Operador">Instinto del Operador</option>
            </select>
        </div>
    `;

            signalPanel.appendChild(card);

            // Auto-mostrar formulario de override después de 30 segundos
            setTimeout(() => {
                showOverrideForm(signal.signal_id);
            }, 30000);
        }

        function showOverrideForm(signalId) {
            const actionsDiv = document.getElementById(`actions-${signalId}`);
            if (!actionsDiv || actionsDiv.querySelector('.override-form')) return;

            actionsDiv.innerHTML = `
                <div class="override-form">
                    <p><strong>¿Por qué ignoraste esta señal?</strong></p>
                    <select id="override-reason-${signalId}" class="override-select">
                        <option value="">Selecciona una razón...</option>
                        <option value="Mal Timing">Mal Timing</option>
                        <option value="Alto Spread">Alto Spread</option>
                        <option value="Volatilidad Inesperada">Volatilidad Inesperada</option>
                        <option value="Instinto del Operador">Instinto del Operador</option>
                        <option value="Condiciones del Mercado">Condiciones del Mercado</option>
                        <option value="Falta de Liquidez">Falta de Liquidez</option>
                    </select>
                    <button class="btn-override" onclick="logOverride('${signalId}')">Registrar Override</button>
                    <button class="btn-close" onclick="removeSignalCard('${signalId}')">Cerrar</button>
                </div>
            `;
        }

// Función para mostrar explicación XAI
async function showExplanation(signalId) {
    try {
        console.log(`🔍 Solicitando explicación para signal: ${signalId}`);

        const response = await fetch(`/api/get_explanation/${signalId}`);
        const data = await response.json();

        if (data.status === 'success') {
            displayExplanationModal(data.explanation);
        } else {
            showNotification('No se encontró explicación para esta señal', 'warning');
        }
    } catch (error) {
        console.error('Error obteniendo explicación:', error);
        showNotification('Error al cargar explicación', 'error');
    }
}

// Función para mostrar modal de explicación
function displayExplanationModal(explanation) {
    // Crear modal
    const modal = document.createElement('div');
    modal.className = 'explanation-modal';
    modal.innerHTML = `
        <div class="explanation-content">
            <div class="explanation-header">
                <h2>🔍 Análisis de Decisión XAI</h2>
                <button class="close-btn" onclick="closeExplanationModal()">&times;</button>
            </div>
            <div class="explanation-body">
                <div class="explanation-summary">
                    <h3>📊 Resumen de Decisión</h3>
                    <p><strong>Decisión:</strong> ${explanation.decision}</p>
                    <p><strong>Signal ID:</strong> ${explanation.signal_id}</p>
                    <p><strong>Timestamp:</strong> ${new Date(explanation.timestamp).toLocaleString()}</p>
                </div>

                <div class="explanation-interpretation">
                    <h3>📝 Interpretación</h3>
                    <pre>${explanation.interpretation || 'No disponible'}</pre>
                </div>

                <div class="explanation-charts">
                    <div class="chart-container">
                        <div id="force-plot-chart"></div>
                    </div>
                    <div class="chart-container">
                        <div id="waterfall-chart"></div>
                    </div>
                    <div class="chart-container">
                        <div id="importance-chart"></div>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modal);

    // Renderizar gráficos con Plotly
    setTimeout(() => {
        if (explanation.force_plot && Object.keys(explanation.force_plot).length > 0) {
            Plotly.newPlot('force-plot-chart', explanation.force_plot.data, explanation.force_plot.layout);
        }

        if (explanation.waterfall_chart && Object.keys(explanation.waterfall_chart).length > 0) {
            Plotly.newPlot('waterfall-chart', explanation.waterfall_chart.data, explanation.waterfall_chart.layout);
        }

        if (explanation.feature_importance && Object.keys(explanation.feature_importance).length > 0) {
            Plotly.newPlot('importance-chart', explanation.feature_importance.data, explanation.feature_importance.layout);
        }
    }, 100);
}

// Función para cerrar modal de explicación
function closeExplanationModal() {
    const modal = document.querySelector('.explanation-modal');
    if (modal) {
        modal.remove();
    }
}

        // Función para marcar el resultado de una señal
        async function markSignalResult(signalId, result) {
            fetch('/api/update_signal_result', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ signal_id: signalId, result: result })
            })
            .then(res => res.json())
            .then(data => {
                console.log('Resultado registrado:', data);
                removeSignalCard(signalId);
            })
            .catch(error => {
                console.error('Error registrando resultado:', error);
            });
        }

        window.logOverride = function(signalId) {
            const reasonSelect = document.getElementById(`override-reason-${signalId}`);
            const reason = reasonSelect.value;

            if (!reason) {
                alert('Por favor selecciona una razón para el override');
                return;
            }

            fetch('/api/log_override', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ signal_id: signalId, reason: reason })
            })
            .then(res => res.json())
            .then(data => {
                console.log('Override registrado:', data);
                addChatMessage(`Override registrado: ${reason} para señal ${signalId.slice(0, 8)}...`, 'bot');
                removeSignalCard(signalId);
            })
            .catch(error => {
                console.error('Error registrando override:', error);
                alert('Error registrando override');
            });
        }

        window.removeSignalCard = function(signalId) {
            const card = document.getElementById(`signal-${signalId}`);
            if (card) {
                card.remove();
            }
        }

        function sendCommand() {
            const command = commandInput?.value.trim();
            if (!command) return;

            addChatMessage(command, 'user');
            commandInput.value = '';

            fetch('/api/strategic_command', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ command: command })
            })
            .then(res => res.json())
            .then(data => {
                addChatMessage(data.response_message || 'Comando procesado', 'bot');
            })
            .catch(error => {
                console.error('Error al enviar comando:', error);
                addChatMessage('Error de comunicación con el Director.', 'bot');
            });
        }

        // Event listeners
        if (sendCommandBtn) {
            sendCommandBtn.addEventListener('click', sendCommand);
        }

        if (commandInput) {
            commandInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') sendCommand();
            });
        }
    }

    // Inicializar conexión
    initializeSocket();
});
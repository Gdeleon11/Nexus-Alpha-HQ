document.addEventListener('DOMContentLoaded', () => {
  const priceSpan = document.getElementById('latest-price');
  const signalSpan = document.getElementById('provisional-signal');
  const verdictSpan = document.getElementById('verdict');
  const verifyButton = document.getElementById('verify-button');

  // Muestra el último precio guardado por el agente de fondo
  chrome.storage.local.get('latest_price', (data) => {
    if (data.latest_price) {
      priceSpan.textContent = `${data.latest_price.asset} @ ${data.latest_price.price}`;
    }
  });

  // Escucha los clics en el botón de verificación
  verifyButton.addEventListener('click', () => {
    verdictSpan.textContent = "Enviando a Replit...";
    chrome.storage.local.get('latest_price', (data) => {
      if (!data.latest_price) {
        verdictSpan.textContent = "Error: No hay precio interceptado.";
        return;
      }
      
      // En un futuro, obtendríamos el signal_id real. Por ahora, usamos uno de prueba.
      const payload = {
        signal_id: "provisional-signal-123",
        live_price: data.latest_price.price
      };
      
      const REPLIT_API_URL = "https://tu-aplicacion.replit.dev/api/verify_signal";

      // Llama a la API de nuestro cerebro en Replit
      fetch(REPLIT_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      })
      .then(response => response.json())
      .then(result => {
        verdictSpan.textContent = result.status;
      })
      .catch(error => {
        verdictSpan.textContent = "Error de conexión.";
        console.error('Error:', error);
      });
    });
  });
});